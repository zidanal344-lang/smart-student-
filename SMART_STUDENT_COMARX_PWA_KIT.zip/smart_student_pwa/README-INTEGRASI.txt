SMART STUDENT – COMARX | PWA + Android APK

ISI PAKET
- manifest.json
- service-worker.js
- icons/icon-192.png
- icons/icon-512.png

LANGKAH INTEGRASI KE INDEX.HTML YANG SUDAH ADA
1. Salin folder icons/, manifest.json, dan service-worker.js ke folder yang sama dengan index.html.
2. Tambahkan baris berikut di dalam <head> pada index.html:

<link rel="manifest" href="/manifest.json">
<meta name="theme-color" content="#1456a0">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<link rel="icon" href="/icons/icon-192.png">

3. Tambahkan sebelum </body> pada index.html:

<script>
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/service-worker.js")
      .then(() => console.log("SMART STUDENT siap digunakan sebagai PWA"))
      .catch(err => console.error("Service Worker gagal:", err));
  });
}
</script>

PENTING
- PWA dan Service Worker harus dihosting melalui HTTPS (localhost hanya untuk pengujian).
- Pastikan index.html berada di root situs agar path /manifest.json dan /service-worker.js benar.
- Service worker menyimpan shell aplikasi untuk membantu membuka halaman saat offline.
- localStorage tetap hanya tersimpan pada perangkat/browser itu. Paket ini TIDAK membuat database online atau sinkronisasi antarperangkat.
- Jangan gunakan data siswa asli sampai autentikasi server dan database aman dipasang.

MEMASANG PWA DI ANDROID
1. Hosting folder proyek di layanan web HTTPS.
2. Buka URL situs di Chrome Android.
3. Pilih menu Chrome > Install app / Tambahkan ke layar utama (nama menu dapat berbeda).
4. Jalankan ikon SMART STUDENT.

MEMBUAT APK ANDROID
1. Setelah PWA online melalui HTTPS, buka https://www.pwabuilder.com/
2. Masukkan URL PWA.
3. Pilih Package for stores > Android > Generate Package.
4. Atur nama aplikasi SMART STUDENT dan package ID unik, misalnya id.comarx.smartstudent (gunakan hanya jika belum dipakai).
5. Unduh paket Android. Ikuti instruksi PWABuilder untuk APK pengujian atau AAB untuk Google Play.
6. Simpan signing key dengan aman. Jangan membagikan file kunci atau passwordnya.

Catatan: APK belum dibuat di paket ini karena memerlukan URL HTTPS milik aplikasi dan proses penandatanganan Android.
